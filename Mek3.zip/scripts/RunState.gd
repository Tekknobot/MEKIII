# res://scripts/RunState.gd
extends Node
class_name RunState

var _keep := UnitRegistry.FORCE_EXPORT

var starting_roster_size: int = 4
var unlock_per_campaign_clear: int = 2

# Overworld / mission
var overworld_seed: int = 0
var overworld_current_node_id: int = -1

var mission_seed: int = 0
var mission_node_type: StringName = &"combat"  # "combat/supply/event/elite/boss/start"
var mission_difficulty: float = 0.0            # 0..1
var mission_node_id: int = -1

var overworld_cleared: Dictionary = {} # node_id -> true
var overworld_current_node: int = -1

var boss_node_ids: Array[int] = []        # all boss nodes in this campaign
var final_boss_node_id: int = -1          # which one ends the campaign
var campaign_cleared: bool = false
var true_clear: bool = false


# -------------------------
# Upgrades (existing)
# -------------------------
var run_upgrades: Array[StringName] = []
var run_upgrade_counts: Dictionary = {} # StringName -> int

# -------------------------
# Squad selection
# -------------------------
var squad_scene_paths: Array[String] = []  # ordered .tscn paths

# -------------------------
# "Quirks" system (NEW)
# -------------------------
# We keep roster_scene_paths as the *unlocked unit types* list (progression).
# roster_units is the player-owned "garage" of individual units.
# Each entry: {"id":String, "path":String, "quirks":Array[StringName]}
var roster_units: Array[Dictionary] = []

# Squad selection by roster unit IDs (so you can have multiple variants of the same base unit).
var squad_unit_ids: Array[String] = []

# -------------------------
# Roster + Recruit pool (NEW)
# -------------------------
var roster_scene_paths: Array[String] = []        # all ally unit .tscn paths discovered
var recruit_pool_paths: Array[String] = []        # remaining recruitable .tscn paths (excludes squad + already recruited)
var recruited_scene_paths: Array[String] = []     # what you’ve recruited so far (optional bookkeeping)

const SAVE_PATH := "user://runstate_save.json"
const SAVE_VERSION := 2

var boss_defeated_this_run: bool = false
var bomber_unlocked_this_run: bool = false

var boss_mode_enabled_next_mission: bool = false
var event_mode_enabled_next_mission: bool = false
var event_id_next_mission: StringName = &""  # e.g. &"titan_overwatch"

# -------------------------
# Supply mission result (NEW)
# -------------------------
var last_supply_success: bool = false
var last_supply_crates_total: int = 0
var last_supply_crates_collected: int = 0
var last_supply_units_evaced: int = 0
var last_supply_reward_tier: int = 0  # 0 none, 1 rough, 2 clean, 3 perfect
var last_supply_failed_reason: String = "" # "missed_crate" / "no_evac" / "wiped" / etc

var dead_scene_paths: Array[String] = []

var run_over := false
var pending_recruit_paths: Array[String] = []  # recruited this mission, not yet earned

# -------------------------
# Achievements (NEW)
# -------------------------
signal achievement_unlocked(id: String, def: Dictionary)

# id:String -> true
var achievements_unlocked: Dictionary = {}
# stat_key:String -> int
var achievement_stats: Dictionary = {}

var squad_entries: Array = [] # each: {"path": String, "quirks": Array[StringName]}

# -------------------------
# Post-mission quirk UI payload (NEW)
# -------------------------
# Array of { "unit_id": String, "quirk_id": StringName }
var last_awarded_quirks: Array[Dictionary] = []

# 20 badges mapped to your pilot_icons/icon_01..icon_20
const ACHIEVEMENT_DEFS: Array[Dictionary] = [
	# 01-03: kill ladders
	{"id":"first_blood",     "title":"First Blood",      "desc":"Kill a zombie.",                 "icon":"res://sprites/Icons/pilot_icons/icon_01.png", "stat":"zombies_killed", "min":1},
	{"id":"body_count_25",   "title":"Body Count",       "desc":"Kill 25 zombies (total).",       "icon":"res://sprites/Icons/pilot_icons/icon_02.png", "stat":"zombies_killed", "min":25},
	{"id":"body_count_100",  "title":"Exterminator",     "desc":"Kill 100 zombies (total).",      "icon":"res://sprites/Icons/pilot_icons/icon_03.png", "stat":"zombies_killed", "min":100},

	# 04: beacon
	{"id":"beacon_online",   "title":"Beacon Online",    "desc":"Fully power the beacon.",        "icon":"res://sprites/Icons/pilot_icons/icon_04.png"},

	# 05: floppy
	{"id":"first_floppy",    "title":"Data Runner",      "desc":"Collect a floppy disk.",         "icon":"res://sprites/Icons/pilot_icons/icon_05.png", "stat":"floppies_collected", "min":1},

	# 06-07: your broken ones (now stat-based)
	{"id":"overwatch",       "title":"Eyes Up",          "desc":"Activate Overwatch.",            "icon":"res://sprites/Icons/pilot_icons/icon_06.png", "stat":"overwatch_activated", "min":1},
	{"id":"mine_trigger",    "title":"Boom Patrol",      "desc":"Detonate a mine on an enemy.",    "icon":"res://sprites/Icons/pilot_icons/icon_07.png", "stat":"mines_detonated", "min":1},

	# 08-10: core “things happen” achievements
	{"id":"demolition",      "title":"Demolition",       "desc":"Destroy a structure.",           "icon":"res://sprites/Icons/pilot_icons/icon_08.png", "stat":"structures_destroyed", "min":1},
	{"id":"weakpoint",       "title":"Weakpoint Hunter", "desc":"Destroy a boss weakpoint.",       "icon":"res://sprites/Icons/pilot_icons/icon_09.png", "stat":"weakpoints_destroyed", "min":1},
	{"id":"ice_cold",        "title":"Cold Feet",        "desc":"Get Chilled (player).",          "icon":"res://sprites/Icons/pilot_icons/icon_10.png", "stat":"player_chilled", "min":1},

	# 11-20: all filled with useful, easy-to-trigger stats
	{"id":"badge_11",        "title":"Backline BBQ",     "desc":"Use Hellfire 5 times.",           "icon":"res://sprites/Icons/pilot_icons/icon_11.png", "stat":"hellfire_used", "min":5},
	{"id":"badge_12",        "title":"Knife Work",       "desc":"Use Blade 5 times.",              "icon":"res://sprites/Icons/pilot_icons/icon_12.png", "stat":"blade_used", "min":5},
	{"id":"badge_13",        "title":"Field Engineer",   "desc":"Place 10 mines.",                 "icon":"res://sprites/Icons/pilot_icons/icon_13.png", "stat":"mines_placed", "min":10},
	{"id":"badge_14",        "title":"Suppressive Fire", "desc":"Use Suppress 5 times.",           "icon":"res://sprites/Icons/pilot_icons/icon_14.png", "stat":"suppress_used", "min":5},
	{"id":"badge_15",        "title":"Juiced",           "desc":"Use Stim 5 times.",               "icon":"res://sprites/Icons/pilot_icons/icon_15.png", "stat":"stim_used", "min":5},

	{"id":"badge_16",        "title":"Linebreaker",      "desc":"Use Sunder 5 times.",             "icon":"res://sprites/Icons/pilot_icons/icon_16.png", "stat":"sunder_used", "min":5},
	{"id":"badge_17",        "title":"Heavy Metal",      "desc":"Use Cannon 5 times.",             "icon":"res://sprites/Icons/pilot_icons/icon_17.png", "stat":"cannon_used", "min":5},
	{"id":"badge_18",        "title":"Shockwave",        "desc":"Use Quake 5 times.",              "icon":"res://sprites/Icons/pilot_icons/icon_18.png", "stat":"quake_used", "min":5},
	{"id":"badge_19",        "title":"Overclocked",      "desc":"Use Overcharge 3 times.",          "icon":"res://sprites/Icons/pilot_icons/icon_19.png", "stat":"overcharge_used", "min":3},
	{"id":"badge_20",        "title":"Boss Slayer",      "desc":"Defeat a boss.",                   "icon":"res://sprites/Icons/pilot_icons/icon_20.png", "stat":"bosses_defeated", "min":1},
]


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)
	
func clear() -> void:
	# "Clear run state" but KEEP unlocked roster.
	run_upgrades.clear()
	run_upgrade_counts.clear()
	squad_scene_paths.clear()
	squad_unit_ids.clear()      # ✅ important: don't reuse prior run's ids
	squad_entries.clear()       # ✅ important: kill fallback cache
	last_awarded_quirks.clear() # ✅ optional: keeps UI clean
	pending_recruit_paths.clear()

	# Don't wipe roster unlock progression
	recruit_pool_paths.clear()
	recruited_scene_paths.clear()
	dead_scene_paths.clear()

	event_mode_enabled_next_mission = false
	event_id_next_mission = &""

	rebuild_recruit_pool()
	save_to_disk()

func add_upgrade(id: StringName) -> void:
	run_upgrades.append(id)
	run_upgrade_counts[id] = int(run_upgrade_counts.get(id, 0)) + 1

func has_upgrade(id: StringName) -> bool:
	return run_upgrade_counts.has(id)

func get_upgrade_count(id: StringName) -> int:
	return int(run_upgrade_counts.get(id, 0))

func set_squad(paths: Array[String]) -> void:
	squad_scene_paths = paths.duplicate()
	# Back-compat: if caller sets paths directly, clear id-based squad.
	squad_unit_ids.clear()
	squad_entries.clear() # ✅ prevent stale entries from hijacking get_squad_defs()

func set_squad_units(ids: Array[String]) -> void:
	squad_unit_ids = ids.duplicate()
	# Keep legacy paths roughly in sync for debugging/older code.
	squad_scene_paths.clear()
	for uid in squad_unit_ids:
		var e := get_roster_unit(uid)
		if not e.is_empty():
			squad_scene_paths.append(str(e.get("path", "")))

func has_squad() -> bool:
	return (not squad_unit_ids.is_empty()) or (not squad_scene_paths.is_empty())

func clear_squad() -> void:
	squad_scene_paths.clear()
	squad_unit_ids.clear()
	squad_entries.clear() # ✅ prevent stale carryover

func get_roster_unit(uid: String) -> Dictionary:
	uid = str(uid)
	for e in roster_units:
		if str(e.get("id", "")) == uid:
			return e
	return {}

func get_roster_units() -> Array[Dictionary]:
	return roster_units.duplicate(true)

func get_squad_defs() -> Array[Dictionary]:
	# Returns [{path:String, id:String, quirks:Array[StringName]}]
	var out: Array[Dictionary] = []

	# ✅ Primary: owned unit ids (this is where quirks live)
	if not squad_unit_ids.is_empty():
		for uid in squad_unit_ids:
			var e := get_roster_unit(str(uid))
			if e.is_empty():
				continue
			var p := str(e.get("path", ""))
			if p == "" or not ResourceLoader.exists(p):
				continue
			var qs: Array[StringName] = []
			for q in e.get("quirks", []):
				qs.append(StringName(str(q)))
			out.append({"id": str(uid), "path": p, "quirks": qs})
		if out.size() > 0:
			return out

	# ✅ Secondary: squad_entries (if you use it)
	if squad_entries != null and squad_entries.size() > 0:
		for e in squad_entries:
			if not (e is Dictionary):
				continue
			var p2 := str(e.get("path", ""))
			if p2 == "":
				continue
			out.append({"id": str(e.get("id","")), "path": p2, "quirks": e.get("quirks", [])})
		if out.size() > 0:
			return out

	# ✅ Fallback: paths-only (no quirks)
	for p3 in squad_scene_paths:
		var ps := str(p3)
		if ps != "":
			out.append({"id": "", "path": ps, "quirks": []})
	return out

func get_squad_packed_scenes() -> Array[PackedScene]:
	# Legacy accessor used by older code paths.
	var out: Array[PackedScene] = []
	var defs := get_squad_defs()
	for d in defs:
		var s = d.get("scene", null)
		if s is PackedScene:
			out.append(s)
	return out

func _make_unit_id(rng: RandomNumberGenerator) -> String:
	# Unique enough for saves: microsecond clock + RNG
	var a := int(Time.get_ticks_usec())  # microseconds since engine start
	var b := rng.randi()
	return "%08x%08x" % [a & 0xffffffff, b & 0xffffffff]

func _add_owned_unit(path: String, quirks: Array[StringName]) -> String:
	path = str(path)
	if path == "" or not ResourceLoader.exists(path):
		return ""

	var rng := RandomNumberGenerator.new()
	rng.randomize() # ✅ do NOT seed with seconds

	var uid := _make_unit_id(rng)

	# ✅ ultra-safety: avoid collisions (should be rare, but cheap)
	var tries := 0
	while tries < 8 and not get_roster_unit(uid).is_empty():
		uid = _make_unit_id(rng)
		tries += 1

	roster_units.append({"id": uid, "path": path, "quirks": quirks.duplicate(true)})
	return uid

func _roll_starting_quirks(rng: RandomNumberGenerator) -> Array[StringName]:
	# Keep early game readable: 0-1 quirks per starter.
	var out: Array[StringName] = []
	if rng.randf() < 0.45:
		var q := QuirkDB.roll_random_quirk(rng, out)
		if q != &"":
			out.append(q)
	return out

func award_post_mission_quirks(evaced_unit_ids: Array[String]) -> void:
	# UI payload for EndGamePanelRuntime
	last_awarded_quirks.clear()

	if evaced_unit_ids.is_empty():
		return

	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system())

	var changed := false

	for uid in evaced_unit_ids:
		uid = str(uid)
		for i in range(roster_units.size()):
			var e := roster_units[i]
			if str(e.get("id", "")) != uid:
				continue

			var qs: Array = e.get("quirks", [])

			if qs.size() < QuirkDB.MAX_QUIRKS_PER_UNIT and rng.randf() < 1.0:
				var qnew := QuirkDB.roll_random_quirk(rng, qs)
				if qnew != &"":
					qs.append(qnew)
					e["quirks"] = qs
					roster_units[i] = e
					changed = true

					# ✅ record for end panel
					last_awarded_quirks.append({
						"unit_id": uid,
						"quirk_id": qnew
					})
			break

	if changed:
		save_to_disk()

# -------------------------
# Roster / recruitment API
# -------------------------
func set_roster(paths: Array[String]) -> void:
	# store all possible ally scenes
	roster_scene_paths = paths.duplicate()

func get_remaining_recruit_count() -> int:
	return recruit_pool_paths.size()

func has_remaining_recruits() -> bool:
	return not recruit_pool_paths.is_empty()

func take_random_recruit_scene(blocked_paths: Array[String] = []) -> PackedScene:
	var blocked: Dictionary = {}
	for p in blocked_paths:
		blocked[str(p)] = true

	var candidates: Array[String] = []
	for p in roster_scene_paths:
		if p == "":
			continue
		var sp := str(p)
		if blocked.has(sp):
			continue
		if not ResourceLoader.exists(sp):
			continue
		candidates.append(sp)

	if candidates.is_empty():
		return null

	var path := candidates[randi() % candidates.size()]
	return load(path) as PackedScene

func _unit_key_from_display_name(s: String) -> String:
	return s.strip_edges().to_upper()

func apply_upgrades_to_unit(u: Node) -> void:
	if u == null or not is_instance_valid(u):
		return

	# --- read display_name ---
	var dn := ""
	if "display_name" in u:
		dn = str(u.display_name)
	elif u.has_meta("display_name"):
		dn = str(u.get_meta("display_name"))
	elif u.has_method("get_display_name"):
		dn = str(u.call("get_display_name"))

	var key := _unit_key_from_display_name(dn)

	# --- current stats ---
	var hp := int(u.max_hp) if ("max_hp" in u) else 0
	var mv := int(u.move_range) if ("move_range" in u) else 0
	var rng := int(u.attack_range) if ("attack_range" in u) else 0
	var dmg := int(u.attack_damage) if ("attack_damage" in u) else 0

	# -------------------------
	# GLOBAL TEAM UPGRADES
	# -------------------------
	hp += get_upgrade_count(&"all_hp_plus_1")
	mv += get_upgrade_count(&"all_move_plus_1")
	dmg += get_upgrade_count(&"all_dmg_plus_1")

	# -------------------------
	# PER-UNIT UPGRADES
	# -------------------------
	match key:

		# SOLDIER
		"SOLDIER":
			mv += get_upgrade_count(&"soldier_move_plus_1")
			rng += get_upgrade_count(&"soldier_range_plus_1")
			dmg += get_upgrade_count(&"soldier_dmg_plus_1")

			if "hellfire_range" in u:
				u.hellfire_range += get_upgrade_count(&"soldier_hellfire_range_plus_1")
			if "hellfire_bonus_damage" in u:
				u.hellfire_bonus_damage += get_upgrade_count(&"soldier_hellfire_damage_plus_1")

			if "suppress_range" in u:
				u.suppress_range += get_upgrade_count(&"soldier_suppress_range_plus_1")
			if "suppress_bonus_damage" in u:
				u.suppress_bonus_damage += get_upgrade_count(&"soldier_suppress_damage_plus_1")
			if "suppress_duration" in u:
				u.suppress_duration += get_upgrade_count(&"soldier_suppress_duration_plus_1")
			if "suppress_move_penalty" in u:
				u.suppress_move_penalty += get_upgrade_count(&"soldier_suppress_penalty_plus_1")

		# MERCENARY
		"MERCENARY":
			mv += get_upgrade_count(&"merc_move_plus_1")
			rng += get_upgrade_count(&"merc_range_plus_1")
			dmg += get_upgrade_count(&"merc_dmg_plus_1")

			if "blade_range" in u:
				u.blade_range += get_upgrade_count(&"merc_blade_range_plus_1")
			if "blade_bonus_damage" in u:
				u.blade_bonus_damage += get_upgrade_count(&"merc_blade_damage_plus_1")
			if "cleave_bonus_damage" in u:
				u.cleave_bonus_damage += get_upgrade_count(&"merc_cleave_damage_plus_1")

			if "stim_duration" in u:
				u.stim_duration += get_upgrade_count(&"merc_stim_duration_plus_1")
			if "stim_move_bonus" in u:
				u.stim_move_bonus += get_upgrade_count(&"merc_stim_move_plus_1")
			if "stim_damage_bonus" in u:
				u.stim_damage_bonus += get_upgrade_count(&"merc_stim_damage_plus_1")

		# ROBODOG
		"ROBODOG":
			hp += 2 * get_upgrade_count(&"dog_hp_plus_2")
			mv += get_upgrade_count(&"dog_move_plus_1")
			dmg += get_upgrade_count(&"dog_dmg_plus_1")

		# BATTLEANGEL
		"BATTLEANGEL":
			hp += get_upgrade_count(&"angel_hp_plus_1")
			mv += get_upgrade_count(&"angel_move_plus_1")
			dmg += get_upgrade_count(&"angel_dmg_plus_1")

		# BLADEGUARD
		"BLADEGUARD":
			hp += get_upgrade_count(&"blade_hp_plus_1")
			mv += get_upgrade_count(&"blade_move_plus_1")
			dmg += get_upgrade_count(&"blade_dmg_plus_1")

			if "sunder_range" in u:
				u.sunder_range += get_upgrade_count(&"blade_sunder_range_plus_1")
			if "sunder_damage" in u:
				u.sunder_damage += get_upgrade_count(&"blade_sunder_dmg_plus_1")

			if "slam_damage" in u:
				u.slam_damage += get_upgrade_count(&"blade_slam_dmg_plus_1")

		# PANTHERBOT
		"PANTHERBOT":
			mv += get_upgrade_count(&"panther_move_plus_1")
			dmg += get_upgrade_count(&"panther_dmg_plus_1")

			if "pounce_range" in u:
				u.pounce_range += get_upgrade_count(&"panther_pounce_range_plus_1")
			if "pounce_damage" in u:
				u.pounce_damage += get_upgrade_count(&"panther_pounce_damage_plus_1")
			if "pounce_knockback" in u:
				u.pounce_knockback += get_upgrade_count(&"panther_pounce_knockback_plus_1")

		# KANNON
		"KANNON":
			rng += get_upgrade_count(&"kannon_range_plus_1")
			dmg += get_upgrade_count(&"kannon_dmg_plus_1")

			if "cannon_damage" in u:
				u.cannon_damage += get_upgrade_count(&"kannon_cannon_damage_plus_1")
			if "cannon_range" in u:
				u.cannon_range += get_upgrade_count(&"kannon_cannon_range_plus_1")

		# SKIMMER
		"SKIMMER":
			mv += get_upgrade_count(&"skimmer_move_plus_1")
			dmg += get_upgrade_count(&"skimmer_dmg_plus_1")

			if "quake_range" in u:
				u.quake_range += get_upgrade_count(&"skimmer_quake_range_plus_1")
			if "quake_damage" in u:
				u.quake_damage += get_upgrade_count(&"skimmer_quake_damage_plus_1")

		# DESTROYER A.I. (FIXED)
		"DESTROYER A.I.":
			hp += 2 * get_upgrade_count(&"destroyer_hp_plus_2")
			dmg += get_upgrade_count(&"destroyer_dmg_plus_1")

		# ARACHNOBOT
		"ARACHNOBOT":
			hp += get_upgrade_count(&"arachno_hp_plus_1")
			mv += get_upgrade_count(&"arachno_move_plus_1")
			dmg += get_upgrade_count(&"arachno_dmg_plus_1")

			if "nova_range" in u:
				u.nova_range += get_upgrade_count(&"arachno_nova_range_plus_1")
			if "nova_damage" in u:
				u.nova_damage += get_upgrade_count(&"arachno_nova_damage_plus_1")
			if "web_range" in u:
				u.web_range += get_upgrade_count(&"arachno_web_range_plus_1")
			if "web_damage" in u:
				u.web_damage += get_upgrade_count(&"arachno_web_damage_plus_1")

		# SCANNERZ
		"SCANNERZ":
			hp += get_upgrade_count(&"scannerz_hp_plus_1")
			mv += get_upgrade_count(&"scannerz_move_plus_1")
			dmg += get_upgrade_count(&"scannerz_dmg_plus_1")

		# EDWARD
		"EDWARD":
			hp += get_upgrade_count(&"edward_hp_plus_1")
			mv += get_upgrade_count(&"edward_move_plus_1")
			dmg += get_upgrade_count(&"edward_dmg_plus_1")

		# DECIMATOR
		"DECIMATOR":
			hp += 2 * get_upgrade_count(&"decimator_hp_plus_2")
			mv += get_upgrade_count(&"decimator_move_plus_1")
			dmg += get_upgrade_count(&"decimator_dmg_plus_1")

		# COBRUH A.I.
		"COBRUH A.I.":
			hp += 2 * get_upgrade_count(&"cobruh_hp_plus_2")
			dmg += get_upgrade_count(&"cobruh_dmg_plus_1")			
			if "drive_move_points" in u:
				u.drive_move_points += get_upgrade_count(&"carbot_drive_move_plus_1")

		# MARV
		"MARV":
			hp += 2 * get_upgrade_count(&"marv_hp_plus_2")
			mv += get_upgrade_count(&"marv_move_plus_1")
			dmg += get_upgrade_count(&"marv_dmg_plus_1")

		# ROLLERBOT
		"ROLLERBOT A.I.":
			hp += 2 * get_upgrade_count(&"rollerbot_hp_plus_2")
			if "roll_distance" in u:
				u.roll_distance += get_upgrade_count(&"rollerbot_roll_plus_1")

	# --- write back ---
	if "max_hp" in u:
		u.max_hp = hp
	if "hp" in u:
		u.hp = clamp(int(u.hp), 0, hp)

	if "move_range" in u:
		u.move_range = mv
	if "attack_range" in u:
		u.attack_range = rng
	if "attack_damage" in u:
		u.attack_damage = dmg

# --- Save / Load -------------------------------------------------
func _ready() -> void:
	load_from_disk()
	seed_roster_if_empty()

	if roster_scene_paths.is_empty():
		roster_scene_paths = UnitRegistry.ALLY_PATHS.duplicate()
		roster_scene_paths = roster_scene_paths.filter(func(p): return ResourceLoader.exists(p))
		roster_scene_paths.sort()

		if squad_scene_paths.is_empty():
			squad_scene_paths = roster_scene_paths.slice(0, min(3, roster_scene_paths.size()))

		rebuild_recruit_pool()
		save_to_disk()


func _build_roster_from_dir(dir_path: String) -> void:
	roster_scene_paths.clear()

	var d := DirAccess.open(dir_path)
	if d == null:
		push_warning("[RUNSTATE] Failed to open allies dir: " + dir_path)
		return

	d.list_dir_begin()
	while true:
		var f := d.get_next()
		if f == "":
			break
		if d.current_is_dir():
			continue
		if f.get_extension().to_lower() == "tscn":
			roster_scene_paths.append(dir_path + "/" + f)
	d.list_dir_end()

	roster_scene_paths.sort()
	print("[RUNSTATE] Roster initialized with ", roster_scene_paths.size(), " units")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_to_disk()

func to_save_dict() -> Dictionary:
	# Serialize roster_units quirks safely (StringName -> String)
	var roster_units_save: Array = []
	for e in roster_units:
		if not (e is Dictionary):
			continue
		var qs: Array = []
		for q in e.get("quirks", []):
			qs.append(String(q))
		roster_units_save.append({
			"id": str(e.get("id", "")),
			"path": str(e.get("path", "")),
			"quirks": qs,
		})

	return {
		"version": SAVE_VERSION,

		# Overworld
		"overworld_seed": overworld_seed,
		"overworld_current_node_id": overworld_current_node_id,
		"overworld_cleared": overworld_cleared.duplicate(true),

		# Mission (optional, but harmless)
		"mission_seed": mission_seed,
		"mission_node_type": String(mission_node_type),
		"mission_difficulty": mission_difficulty,
		"mission_node_id": mission_node_id,

		# Upgrades / run
		"run_upgrades": run_upgrades.map(func(x): return String(x)),
		"run_upgrade_counts": _dict_stringname_to_string(run_upgrade_counts),

		# Squad / roster / recruits
		"squad_scene_paths": squad_scene_paths.duplicate(),
		"squad_unit_ids": squad_unit_ids.duplicate(),
		"roster_scene_paths": roster_scene_paths.duplicate(),
		"roster_units": roster_units_save,
		"recruit_pool_paths": recruit_pool_paths.duplicate(),
		"recruited_scene_paths": recruited_scene_paths.duplicate(),
		"dead_scene_paths": dead_scene_paths.duplicate(),

		"event_mode_enabled_next_mission": event_mode_enabled_next_mission,
		"event_id_next_mission": String(event_id_next_mission),
		
		"last_supply_success": last_supply_success,
		"last_supply_crates_total": last_supply_crates_total,
		"last_supply_crates_collected": last_supply_crates_collected,
		"last_supply_units_evaced": last_supply_units_evaced,
		"last_supply_reward_tier": last_supply_reward_tier,
		"last_supply_failed_reason": last_supply_failed_reason,

		# Achievements
		"achievements_unlocked": achievements_unlocked.keys(),
		"achievement_stats": achievement_stats.duplicate(true),

		"boss_node_ids": boss_node_ids.duplicate(),
		"final_boss_node_id": final_boss_node_id,
		"campaign_cleared": campaign_cleared,
		"true_clear": true_clear,

	}

func load_from_save_dict(d: Dictionary) -> void:
	if d.is_empty():
		return

	# Overworld
	overworld_seed = int(d.get("overworld_seed", overworld_seed))
	overworld_current_node_id = int(d.get("overworld_current_node_id", overworld_current_node_id))
	overworld_cleared = d.get("overworld_cleared", {}).duplicate(true)

	# Mission
	mission_seed = int(d.get("mission_seed", mission_seed))
	mission_node_type = StringName(str(d.get("mission_node_type", String(mission_node_type))))
	mission_difficulty = float(d.get("mission_difficulty", mission_difficulty))
	mission_node_id = int(d.get("mission_node_id", mission_node_id))

	# Upgrades
	run_upgrades.clear()
	for s in d.get("run_upgrades", []):
		run_upgrades.append(StringName(str(s)))
	run_upgrade_counts = _dict_string_to_stringname_counts(d.get("run_upgrade_counts", {}))

	# Squad / roster / recruits
	squad_scene_paths.clear()
	squad_scene_paths.append_array(d.get("squad_scene_paths", []))

	squad_unit_ids.clear()
	squad_unit_ids.append_array(d.get("squad_unit_ids", []))

	roster_scene_paths.clear()
	roster_scene_paths.append_array(d.get("roster_scene_paths", []))

	# roster_units (v2+) - migrate safely
	roster_units.clear()
	for raw in d.get("roster_units", []):
		if not (raw is Dictionary):
			continue
		var p := str(raw.get("path", ""))
		if p == "" or not ResourceLoader.exists(p):
			continue
		var uid := str(raw.get("id", ""))
		if uid == "":
			# generate a replacement id
			var rng := RandomNumberGenerator.new()
			rng.seed = int(Time.get_unix_time_from_system())
			uid = _make_unit_id(rng)
		var qs: Array[StringName] = []
		for q in raw.get("quirks", []):
			var qid := StringName(str(q))
			if QuirkDB.has_def(qid):
				qs.append(qid)
		roster_units.append({"id": uid, "path": p, "quirks": qs})

	_ensure_roster_units_exist()

	recruit_pool_paths.clear()
	recruit_pool_paths.append_array(d.get("recruit_pool_paths", []))

	recruited_scene_paths.clear()
	recruited_scene_paths.append_array(d.get("recruited_scene_paths", []))

	dead_scene_paths.clear()
	dead_scene_paths.append_array(d.get("dead_scene_paths", []))
	
	last_supply_success = bool(d.get("last_supply_success", false))
	last_supply_crates_total = int(d.get("last_supply_crates_total", 0))
	last_supply_crates_collected = int(d.get("last_supply_crates_collected", 0))
	last_supply_units_evaced = int(d.get("last_supply_units_evaced", 0))
	last_supply_reward_tier = int(d.get("last_supply_reward_tier", 0))
	last_supply_failed_reason = str(d.get("last_supply_failed_reason", ""))

	boss_node_ids.clear()
	for v in d.get("boss_node_ids", []):
		boss_node_ids.append(int(v))

	final_boss_node_id = int(d.get("final_boss_node_id", -1))
	campaign_cleared = bool(d.get("campaign_cleared", false))
	true_clear = bool(d.get("true_clear", false))

	# Achievements
	achievements_unlocked.clear()
	for a in d.get("achievements_unlocked", []):
		achievements_unlocked[str(a)] = true
	achievement_stats = d.get("achievement_stats", {}).duplicate(true)
	_check_stat_achievements()
	
func save_to_disk() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("RunState save failed: " + str(FileAccess.get_open_error()))
		return
	var json := JSON.stringify(to_save_dict())
	f.store_string(json)
	f.close()

func load_from_disk() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var txt := f.get_as_text()
	f.close()

	var parsed = JSON.parse_string(txt)
	if typeof(parsed) == TYPE_DICTIONARY:
		load_from_save_dict(parsed)

func wipe_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
		achievements_unlocked.clear()
		achievement_stats.clear()

func _dict_stringname_to_string(d: Dictionary) -> Dictionary:
	var out := {}
	for k in d.keys():
		out[String(k)] = int(d[k])
	return out

func _dict_string_to_stringname_counts(d: Dictionary) -> Dictionary:
	var out := {}
	for k in d.keys():
		out[StringName(str(k))] = int(d[k])
	return out

func reset_run(wipe_progression: bool = true) -> void:
	# wipe_progression=true  -> FACTORY RESET (wipe roster_units/quirks/unlocks)
	# wipe_progression=false -> NEW RUN (keep roster_units + quirks)

	# overworld
	overworld_seed = int(Time.get_unix_time_from_system())
	overworld_current_node_id = -1
	overworld_cleared.clear()
	overworld_current_node = -1

	# mission
	mission_seed = 0
	mission_node_type = &"combat"
	mission_difficulty = 0.0
	mission_node_id = -1

	# upgrades (run-scoped)
	run_upgrades.clear()
	run_upgrade_counts.clear()

	# flags
	event_mode_enabled_next_mission = false
	event_id_next_mission = &""
	boss_mode_enabled_next_mission = false
	boss_defeated_this_run = false
	bomber_unlocked_this_run = false
	run_over = false

	# squad / deploy selections
	squad_scene_paths.clear()
	squad_unit_ids.clear()
	squad_entries.clear()

	# recruits / run bookkeeping
	recruit_pool_paths.clear()
	recruited_scene_paths.clear()
	pending_recruit_paths.clear()
	last_supply_success = false
	last_supply_crates_total = 0
	last_supply_crates_collected = 0
	last_supply_units_evaced = 0
	last_supply_reward_tier = 0
	last_supply_failed_reason = ""

	# permadeath list (run-scoped)
	dead_scene_paths.clear()

	if wipe_progression:
		# ✅ FACTORY RESET: wipe progression + owned garage variants (removes quirks)
		roster_scene_paths.clear()
		roster_units.clear()

		# achievements too (your current behavior)
		achievements_unlocked.clear()
		achievement_stats.clear()

		# reseed everything from scratch
		seed_roster_if_empty()
		_ensure_roster_units_exist()
	else:
		# ✅ NEW RUN: keep roster_units + quirks
		# (but ensure it exists / migrated)
		_ensure_roster_units_exist()

	# rebuild recruit pool using whatever roster exists now
	rebuild_recruit_pool()

	save_to_disk()

func seed_roster_if_empty() -> void:
	# If roster already exists, don't stomp it
	if not roster_scene_paths.is_empty():
		return

	var all: Array[String] = UnitRegistry.ALLY_PATHS.duplicate()
	all = all.filter(func(p): return ResourceLoader.exists(p))
	all.sort()

	# Deterministic shuffle based on overworld_seed (so "new run" can differ)
	var rng := RandomNumberGenerator.new()
	rng.seed = int(overworld_seed) if overworld_seed != 0 else int(Time.get_unix_time_from_system())

	# Fisher–Yates shuffle
	for i in range(all.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp := all[i]
		all[i] = all[j]
		all[j] = tmp

	# Take only first N
	var n = clamp(starting_roster_size, 1, all.size())
	roster_scene_paths.clear()
	roster_units.clear()
	for i in range(n):
		roster_scene_paths.append(all[i])
		# Create an owned unit variant with 0-1 starting quirks
		var qs := _roll_starting_quirks(rng)
		_add_owned_unit(all[i], qs)

	# Build recruit pool from roster
	rebuild_recruit_pool()

	print("[RUNSTATE] Seeded START roster_scene_paths=", roster_scene_paths.size(),
		" recruit_pool_paths=", recruit_pool_paths.size())

func _ensure_roster_units_exist() -> void:
	# Migration / back-compat: older saves have roster_scene_paths but no roster_units.
	if not roster_units.is_empty():
		return
	if roster_scene_paths.is_empty():
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system())
	for p in roster_scene_paths:
		_add_owned_unit(str(p), [])

func unlock_more_roster(count: int) -> Array[String]:
	var unlocked_now: Array[String] = []

	var all: Array[String] = UnitRegistry.ALLY_PATHS.duplicate()
	all = all.filter(func(p): return ResourceLoader.exists(p))
	all.sort()

	# Candidates = not already in roster, not dead
	var candidates: Array[String] = []
	for p in all:
		var sp := str(p)
		if roster_scene_paths.has(sp):
			continue
		if dead_scene_paths.has(sp):
			continue
		candidates.append(sp)

	if candidates.is_empty():
		return unlocked_now

	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system())

	for k in range(min(count, candidates.size())):
		var idx := rng.randi_range(0, candidates.size() - 1)
		var pick := candidates[idx]
		candidates.remove_at(idx)

		roster_scene_paths.append(pick)
		unlocked_now.append(pick)
		# Getting a new chassis also adds a new owned unit (starts with 0-1 quirks)
		var qs := _roll_starting_quirks(rng)
		_add_owned_unit(pick, qs)

	rebuild_recruit_pool()
	save_to_disk()
	return unlocked_now

func is_dead(path: String) -> bool:
	return dead_scene_paths.has(path)

func mark_dead(path: String) -> void:
	path = str(path)
	if path == "":
		return
	if dead_scene_paths.has(path):
		return

	dead_scene_paths.append(path)

	# Remove from this run only
	squad_scene_paths.erase(path)
	recruit_pool_paths.erase(path)

func recruit_joined_team(path: String) -> void:
	# Called when a recruit is spawned on a map (RUN-ONLY)
	path = str(path)
	if path == "" or is_dead(path):
		return

	# ❌ DO NOT unlock here anymore.
	# Unlocking must happen on evac via finalize_recruits_after_evac()

	# Fill vacancies only (optional)
	if squad_scene_paths.size() < 3 and not squad_scene_paths.has(path):
		squad_scene_paths.append(path)

	# Not recruitable again this run
	recruit_pool_paths.erase(path)
	if not recruited_scene_paths.has(path):
		recruited_scene_paths.append(path)

	save_to_disk()


func rebuild_recruit_pool() -> void:
	# (your existing logic, but also exclude dead)
	recruit_pool_paths.clear()

	var taken: Dictionary = {}
	for p in squad_scene_paths:
		taken[str(p)] = true
	for p in recruited_scene_paths:
		taken[str(p)] = true
	for p in dead_scene_paths:
		taken[str(p)] = true

	for p in roster_scene_paths:
		var sp := str(p)
		if not taken.has(sp):
			recruit_pool_paths.append(sp)

func get_locked_unit_paths() -> Array[String]:
	var all: Array[String] = UnitRegistry.ALLY_PATHS.duplicate()
	all = all.filter(func(p): return ResourceLoader.exists(p))

	var unlocked: Dictionary = {}
	for p in roster_scene_paths:
		unlocked[str(p)] = true

	var locked: Array[String] = []
	for p in all:
		var sp := str(p)
		if not unlocked.has(sp):
			locked.append(sp)

	return locked

func peek_random_locked_unit_scene(blocked_paths: Array[String] = []) -> PackedScene:
	var blocked: Dictionary = {}
	for p in blocked_paths:
		blocked[str(p)] = true

	var candidates := get_locked_unit_paths()
	candidates = candidates.filter(func(p):
		var sp := str(p)
		return (not blocked.has(sp)) and ResourceLoader.exists(sp)
	)

	if candidates.is_empty():
		return null

	var path := str(candidates[randi() % candidates.size()])
	return load(path) as PackedScene

func recruit_spawned_pending(path: String) -> void:
	path = str(path)
	if path == "" or is_dead(path):
		return
	if not pending_recruit_paths.has(path):
		pending_recruit_paths.append(path)

func finalize_recruits_after_evac(evaced_paths: Array[String]) -> Array[String]:
	# returns what got permanently unlocked this time
	var unlocked: Array[String] = []
	var ev: Dictionary = {}
	for p in evaced_paths:
		ev[str(p)] = true

	# Only finalize those pending AND evac'd
	for p in pending_recruit_paths:
		var sp := str(p)
		if ev.has(sp):
			if not roster_scene_paths.has(sp):
				roster_scene_paths.append(sp)
				unlocked.append(sp)
				# New owned unit variant on unlock
				var rng := RandomNumberGenerator.new()
				rng.seed = int(Time.get_unix_time_from_system())
				var qs := _roll_starting_quirks(rng)
				_add_owned_unit(sp, qs)

	# Clear pending after mission
	pending_recruit_paths.clear()
	rebuild_recruit_pool()
	save_to_disk()
	return unlocked


# -------------------------
# Achievements API
# -------------------------
func get_all_achievement_defs() -> Array[Dictionary]:
	return ACHIEVEMENT_DEFS

func get_achievement_def(id: String) -> Dictionary:
	for d in ACHIEVEMENT_DEFS:
		if str(d.get("id","")) == id:
			return d
	return {}

func is_achievement_unlocked(id: String) -> bool:
	return achievements_unlocked.has(id)

func unlock_achievement(id: String) -> bool:
	if id == "":
		return false
	if achievements_unlocked.has(id):
		return false
	achievements_unlocked[id] = true
	# Save immediately so the unlock survives crashes / quits
	save_to_disk()
	var d := get_achievement_def(id)
	emit_signal("achievement_unlocked", id, d)
	return true

func record_stat(key: String, delta: int = 1) -> void:
	if key == "":
		return
	achievement_stats[key] = int(achievement_stats.get(key, 0)) + int(delta)
	_check_stat_achievements()

func get_stat(key: String) -> int:
	return int(achievement_stats.get(key, 0))

func _check_stat_achievements() -> void:
	# Unlock any achievements gated by stats
	for d in ACHIEVEMENT_DEFS:
		if not d.has("stat"):
			continue
		var id := str(d.get("id",""))
		if id == "" or achievements_unlocked.has(id):
			continue
		var stat_key := str(d.get("stat",""))
		var minv := int(d.get("min", 0))
		if stat_key != "" and get_stat(stat_key) >= minv:
			unlock_achievement(id)

func set_squad_entries(entries: Array) -> void:
	squad_entries = entries.duplicate(true)

	# keep paths for legacy code that expects them
	squad_scene_paths.clear()
	for e in squad_entries:
		if e is Dictionary and e.has("path"):
			squad_scene_paths.append(str(e["path"]))

	# ensure ids don’t override anything
	squad_unit_ids.clear()

	save_to_disk()

func set_boss_nodes(ids: Array, final_id: int) -> void:
	boss_node_ids.clear()
	for v in ids:
		boss_node_ids.append(int(v))
	final_boss_node_id = int(final_id)

func is_final_boss_node(node_id: int) -> bool:
	return final_boss_node_id != -1 and node_id == final_boss_node_id
